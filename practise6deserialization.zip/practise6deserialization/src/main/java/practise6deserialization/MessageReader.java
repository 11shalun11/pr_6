package practise6deserialization;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;

public class MessageReader {

    public static void main(String[] args) {
        System.out.println("РИБО-01-21, Практика №6, Вариант №2, Шалунова А.С.");
        try {
            System.out.print("Введите путь к файлу: ");
            String filePath = new java.util.Scanner(System.in).nextLine();
            FileInputStream fileIn = new FileInputStream(filePath);
            ObjectInputStream objIn = new ObjectInputStream(fileIn);
            Message message = (Message) objIn.readObject();
            System.out.println("id: " + message.getId());
            System.out.println("body: " + message.getBody());
            System.out.println("type: " + message.getType());
            System.out.println("hasAttachments: " + message.hasAttachments());
            System.out.println("timestamp: " + message.getTimestamp());
            objIn.close();
            fileIn.close();
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    }
}
