package practise6deserialization;

public class Message {
    private int id;
    private String body;
    private String type;
    private boolean hasAttachments;
    private long timestamp;
    private final long VERSION_CONTROL = -3380157693869190848L;

    public Message(int id, String body, String type, boolean hasAttachments, long timestamp) {
        this.id = id;
        this.body = body;
        this.type = type;
        this.hasAttachments = hasAttachments;
        this.timestamp = timestamp;
    }
    public int getId() {
        return id;
    }
    public String getBody() {
        return body;
    }
    public String getType() {
        return type;
    }
    public boolean hasAttachments() {
        return hasAttachments;
    }
    public long getTimestamp() {
        return timestamp;
    }
    public long getVersionControl() {
        return VERSION_CONTROL;
    }
}